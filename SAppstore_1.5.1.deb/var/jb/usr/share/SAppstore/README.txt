SAppstore 1.5.1  -  Developer: SerdarStone
==========================================
App Store icin eski surum indirme tweak'i (iOS 15 - 18)

1) ESKI SURUM LISTESI
   - App Store'da bir uygulamanin sayfasina gir.
   - "AL / GET" veya bulut (yeniden indir) butonuna yarim saniye UZUN BAS.
   - Sadece o uygulamanin surumleri (uygulama ikonuyla) listelenir.
     Liste tarihe gore siralidir (en yeni tarih en ustte, ilk surum en altta).
     Istedigin surume dokun, "Indir" de. Ustteki kutudan surum arayabilirsin.
   - Uygulama gercekten yukluyse (sistem "yuklu" diyor VE buton AC/OPEN gosteriyorsa)
     tweak butona basip uygulamayi acmak yerine dogrudan indirme istegi gonderir.
     Eski surum icin yine de once uygulamayi silmen gerekebilir.

2) ID ILE SURUM BULMA (App Store icinde)
   - App Store'da ekranda yuzen SAppstore ikonuna dokun (veya alttaki sekme
     cubuguna yaklasik 1 sn uzun bas).
   - Ikonu parmaginla tutup ekranda ISTEDIGIN YERE surukleyebilirsin; konumu hatirlanir.
   - Store ID / App Store linki ya da Bundle ID gir (ornek: com.burbn.instagram).
   - "Surumleri Getir": uygulamanin tum surumleri otomatik listelenir.
   - Surume dokun, "Indir" de: App Store'a yonlenmeden dogrudan indirme istegi gonderilir.
     Bu basarisiz olursa tweak uygulama sayfasini acip GET butonuna kendisi basar.

3) ACMA / KAPATMA
   Ayarlar > SAppstore > "Tweak Aktif" anahtari. Kapaliyken ikon gizlenir,
   uzun basislar calismaz.

NOTLAR
- Surum listesi ve bundle ID aramasi internetten yapilir, internet gerekir.
- Sorun olursa Console'da "[SAppstore]" satirlarina bak.
- Ayarlar girisi icin PreferenceLoader gerekir (Sileo/Zebra otomatik kurar).
